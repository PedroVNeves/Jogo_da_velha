import Meu_Modulo.jogovelha as jogovelha

Jogo = jogovelha.JogoVelha()
Jogo.Jogar()
